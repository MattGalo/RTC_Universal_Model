def compute_drtc(mass, volume, age):
    return mass / (volume * age)
